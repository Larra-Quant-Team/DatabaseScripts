credentials = {
    "user": "dbUser",
    "password": "Larra.2020",
    "dbname": "symphony",
    "host": "amalgama-fbqlw.mongodb.net",
    "args": "test?retryWrites=true&w=majority",
    "port": 27017
}
