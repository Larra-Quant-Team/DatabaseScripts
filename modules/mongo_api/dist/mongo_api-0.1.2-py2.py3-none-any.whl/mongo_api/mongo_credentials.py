credentials = {
    "user": "quantUser",# "dbUser"
    "password": "Quant.L4rr4?", # "Larra.2020"
    "dbname": "QuantRepo",
    "host": "quant-main.5pkxp.mongodb.net", # "amalgama-fbqlw.mongodb.net"
    "args": "test?retryWrites=true&w=majority",
    "port": 27017
}
